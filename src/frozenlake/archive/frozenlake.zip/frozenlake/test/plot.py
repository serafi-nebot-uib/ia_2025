import numpy as np
import matplotlib.pyplot as plt
from matplotlib.axes import Axes
from functools import reduce
from operator import getitem
from typing import Any
import math

def get_item(data: dict[str, Any], *path: str) -> Any: return reduce(getitem, path, data)
def get_data(data: dict[str, Any], *path: str) -> dict: return { k: get_item(data[k], *path) for k in data}

def policy(p: np.ndarray, v: np.ndarray | None, map_desc: np.ndarray, ax: Axes):
  if v is None: v = np.zeros_like(p)
  N = map_desc.shape[0]
  v = v.reshape(N, N)
  p = p.reshape(N, N)

  syms = ["←", "↓", "→", "↑"]
  ax.imshow(v, cmap="Blues")
  for y in range(N):
    for x in range(N):
      if map_desc[y, x] in (b"H", b"G"): continue
      ax.text(x, y, syms[p[y, x]], ha="center", va="center", fontsize=26, color="black", fontweight="bold")

def qtable(data: dict, map_desc: np.ndarray):
  figs = []
  for name in data:
    if "q" in data[name]:
      fig, (axq, axp) = plt.subplots(nrows=1, ncols=2, figsize=(6 * 2, 6))

      q = np.array(data[name]["q"])
      N = int(np.sqrt(q.shape[0]))
      v = q.max(axis=-1).reshape(N, N)
      p = q.argmax(axis=-1).reshape(N, N)

      axq.imshow(v, cmap="Blues")

      # apply softmax to get arrow lengths proportionate to each action's value
      shifted_q = q - q.max(axis=-1, keepdims=True) # shift for numerical stability
      exp_q = np.exp(shifted_q)

      anorm = (exp_q / exp_q.sum(axis=-1, keepdims=True)).reshape(N, N, -1, 1)
      #                 left     down    right   up
      adir = np.array([[-1, 0], [0, 1], [1, 0], [0, -1]])
      arrow = adir * anorm

      for y in range(arrow.shape[0]):
        for x in range(arrow.shape[1]):
          if map_desc[y, x] in (b"H", b"G"): continue
          for a in range(arrow.shape[2]):
            dx, dy = arrow[y, x, a]
            axq.arrow(x, y, dx, dy,
                    head_width=0.08, head_length=0.08,
                    fc="white", ec="black", alpha=0.8,
                    length_includes_head=True, clip_on=True)

      policy(p, v, map_desc, axp)

      axq.set_xticks([])
      axq.set_yticks([])
      axp.set_xticks([])
      axp.set_yticks([])
      fig.suptitle(f"{name} Q Table", fontsize=16, fontweight="bold", color="black", ha="center", va="top")
      fig.tight_layout()
    else:
      fig, ax = plt.subplots(nrows=1, ncols=1, figsize=(6, 6))
      p = np.array(data[name]["policy"])
      policy(p, None, map_desc, ax)
      ax.set_xticks([])
      ax.set_yticks([])
      fig.suptitle(f"{name} Policy", fontsize=16, fontweight="bold", color="black", ha="center", va="top")
      fig.tight_layout()
    figs.append(fig)


  return figs

def sma(x: list[float] | np.ndarray, m: int) -> np.ndarray: return np.convolve(x, np.ones(m) / m, mode="valid")

def plot_sma(y: list[float] | np.ndarray, label: str, m: int, ax: Axes, **pltopts):
  y = sma(y, m)
  x = np.arange(len(y)) + m
  ax.plot(x, y, label=label, **pltopts)
  ax.set_xlim((0, x.max() + m))

def train_perf(data: dict, m: int = 1):
  data = get_data(data, "train", "perf")
  fig, ax = plt.subplots(figsize=(8, 6))
  for name, values in data.items(): plot_sma(values, name, m, ax)
  ax.set_yticks(np.arange(0, 1.0 + 0.1, 0.1))
  ax.set_ylabel("success rate")
  ax.set_xlabel("iterations")
  agg = f" (SMA {m})" if m > 1 else " "
  fig.suptitle("Train Success Rate" + agg, fontsize=16, fontweight="bold", color="black", ha="center", va="top")
  fig.legend(loc="upper right")
  fig.tight_layout()
  return fig

def train_time(data: dict, m: int = 1):
  data = get_data(data, "train", "time")
  fig, ax = plt.subplots(figsize=(8, 6))
  for name, values in data.items(): plot_sma(values, name, m, ax)
  ax.set_ylabel("time (s)")
  ax.set_xlabel("iterations")
  agg = f" (SMA {m})" if m > 1 else " "
  fig.suptitle("Train Iteration Time" + agg, fontsize=16, fontweight="bold", color="black", ha="center", va="top")
  fig.legend(loc="upper right")
  return fig

def train_steps(data: dict, m: int = 1):
  data = get_data(data,"train", "steps")
  fig, ax = plt.subplots(figsize=(8, 6))
  for name, values in data.items(): plot_sma(values, name, m, ax)
  ax.set_ylabel("steps")
  ax.set_xlabel("iterations")
  agg = f" (SMA {m})" if m > 1 else " "
  fig.suptitle("Train Episode Steps" + agg, fontsize=16, fontweight="bold", color="black", ha="center", va="top")
  fig.legend(loc="upper right")
  return fig

def train_steps_time(data: dict, m: int = 1):
  data_steps = get_data(data,"train", "steps")
  data_time = get_data(data,"train", "time")
  fig, axs = plt.subplots(figsize=(8, 6))
  axs.set_ylabel("steps")
  axs.set_xlabel("iterations")
  axt = axs.twinx()
  axt.set_ylabel("time (s)")

  for name, values in data_steps.items(): plot_sma(values, name, m, axs, linestyle="-")
  for name, values in data_time.items(): plot_sma(values, name, m, axt, linestyle="--", colors=[])

  agg = f" (SMA {m})" if m > 1 else " "
  fig.suptitle("Train Episode Steps & Time" + agg, fontsize=16, fontweight="bold", color="black", ha="center", va="top")
  fig.legend(loc="upper right")
  return fig

def train_actions(data: dict):
  data = get_data(data, "train", "actions", "total")
  fig, ax = plt.subplots(figsize=(8, 6))
  width = 0.45
  
  # TODO: do not hardcode (get from env?)
  actions = ["left", "down", "right", "up"]
  x = np.arange(len(actions))
  for i, (label, values) in enumerate(data.items()):
    ax.bar(x + i * len(actions), values, width=width, label=label)

  ax.set_xticks(np.arange(len(actions) * len(data)), actions * len(data))
  ax.set_ylabel("number of actions")
  fig.suptitle("Train Chosen Actions", fontsize=16, fontweight="bold", color="black", ha="center", va="top")
  fig.legend()
  fig.tight_layout()

def train_actions_history(data: dict):
  data = get_data(data, "train", "actions", "history")
  actions = ["left", "down", "right", "up"]
  ncols = 3
  nrows = math.ceil(len(data) / ncols)
  fig, axs = plt.subplots(nrows=nrows, ncols=ncols, figsize=(5 * ncols, 5 * nrows))

  for (label, values), ax in zip(data.items(), axs):
    y = np.array(values)
    y = y / y.sum(axis=-1, keepdims=True)
    y = y.transpose()
    ax.stackplot(np.arange(y.shape[1]), y)
    ax.set_title(label)
    ax.set_xlabel("iterations")

  fig.legend(labels=actions)
  fig.suptitle("Train Action History Distribution", fontsize=16, fontweight="bold", color="black", ha="center", va="top")
  fig.tight_layout()
  return fig

def test_steps(data: dict):
  data = get_data(data, "test", "steps")
  fig, ax = plt.subplots(figsize=(8, 6))
  labels, values = zip(*data.items())
  ax.boxplot(values, whis=(0, 100), vert=True)
  ax.set_xticklabels(labels, rotation=90)
  ax.set_ylabel("steps")
  fig.suptitle("Test Steps in Episode", fontsize=16, fontweight="bold", color="black", ha="center", va="top")
  fig.tight_layout()
  return fig